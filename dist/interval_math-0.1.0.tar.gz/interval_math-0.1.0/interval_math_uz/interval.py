class IntervalArithmetic:
    def __init__(self, lower, upper):
        if lower > upper:
            raise ValueError("Quyi chegara yuqori chegaradan katta bo‘lishi mumkin emas!")
        self.lower = lower
        self.upper = upper

    def __repr__(self):
        return f"[{self.lower}, {self.upper}]"

    def __add__(self, other):
        if isinstance(other, IntervalArithmetic):
            return IntervalArithmetic(self.lower + other.lower, self.upper + other.upper)
        return IntervalArithmetic(self.lower + other, self.upper + other)

    def __sub__(self, other):
        if isinstance(other, IntervalArithmetic):
            return IntervalArithmetic(self.lower - other.upper, self.upper - other.lower)
        return IntervalArithmetic(self.lower - other, self.upper - other)

    def __mul__(self, other):
        if isinstance(other, IntervalArithmetic):
            values = [self.lower * other.lower, self.lower * other.upper,
                      self.upper * other.lower, self.upper * other.upper]
            return IntervalArithmetic(min(values), max(values))
        return IntervalArithmetic(self.lower * other, self.upper * other)

    def __truediv__(self, other):
        if isinstance(other, IntervalArithmetic):
            if other.lower <= 0 <= other.upper:
                raise ValueError("Cheksiz bo'lishi mumkin!")
            values = [self.lower / other.lower, self.lower / other.upper,
                      self.upper / other.lower, self.upper / other.upper]
            return IntervalArithmetic(min(values), max(values))
        if other == 0:
            raise ValueError("0 ga bo‘lish mumkin emas!")
        return IntervalArithmetic(self.lower / other, self.upper / other)
